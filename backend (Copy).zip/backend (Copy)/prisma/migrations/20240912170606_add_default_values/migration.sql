-- AlterTable
ALTER TABLE "Request" ALTER COLUMN "reqHeaders" SET DEFAULT '',
ALTER COLUMN "reqParams" SET DEFAULT '';
